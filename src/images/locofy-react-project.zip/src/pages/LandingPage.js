import "./LandingPage.css";

const LandingPage = () => {
  return (
    <div className="landing-page">
      <img className="ride-evee-logo-1" alt="" src="/ride-evee-logo-1@2x.png" />
      <img className="landing-page-child" alt="" src="/rectangle-3923@2x.png" />
      <div className="indias-leading-one-way">
        ​India's Leading One-Way Inter-City Cab Service Provider
      </div>
      <img className="vector-icon" alt="" src="/vector.svg" />
      <img className="landing-page-item" alt="" src="/group-1686551468.svg" />
      <div className="landing-page-inner" />
      <div className="why-choose-yatri">Why choose Yatri Car Rental?</div>
      <img className="image-5-icon" alt="" src="/image-5@2x.png" />
      <img
        className="vuesaxlinearpeople-icon"
        alt=""
        src="/vuesaxlinearpeople.svg"
      />
      <img
        className="vuesaxlinearmoney-recive-icon"
        alt=""
        src="/vuesaxlinearmoneyrecive.svg"
      />
      <div className="fast-response-time-parent">
        <div className="fast-response-time">Fast response time</div>
        <div className="avail-best-car">
          Avail Best Car Rental Service in Lucknow with driver for Local or
          Outstation within the moment of your call for best car hire
          experience.
        </div>
      </div>
      <div className="vast-fleet-parent">
        <div className="vast-fleet">Vast fleet</div>
        <div className="we-have-all">
          We have all kinds of Car on Rent available like Sedan, Suv, Muv,
          Premium Sedan, Tampo Traveller etc as per ur requirement
        </div>
      </div>
      <div className="great-tariffs-parent">
        <div className="great-tariffs">Great tariffs</div>
        <div className="rent-a-car">{`Rent A Car !Our car hire tariff are very low when compare to other operators in Lucknow. Book online cabs with best prices in Lucknow at Yatri Car Rental `}</div>
      </div>
      <div className="easy-to-order-parent">
        <div className="easy-to-order">Easy to order</div>
        <div className="easily-book-cab">
          Easily Book Cab Online with our website or call our customer support
          team
        </div>
      </div>
      <div className="why-choose-oneway">Why Choose Oneway Cab?</div>
      <div className="iconsaxlinearpeople" />
      <img className="car-1057-1-icon" alt="" src="/car1057-1.svg" />
      <div className="line-div" />
      <div className="instant-booking-container">
        <ul className="instant-booking">{`Instant Booking & Confirmation`}</ul>
      </div>
      <div className="confirmed-booking-immediately-container">
        <ul className="instant-booking">Confirmed Booking Immediately</ul>
      </div>
      <div className="no-return-fare-container">
        <ul className="instant-booking">No Return Fare for One-Way Trip</ul>
      </div>
      <div className="clean-professional-container">
        <ul className="instant-booking">{`Clean & Professional Cab Services`}</ul>
      </div>
      <div className="no-night-or-container">
        <ul className="instant-booking">No Night or Luggage Charges</ul>
      </div>
      <div className="dedicated-cab-just-container">
        <ul className="instant-booking">Dedicated Cab just for you</ul>
      </div>
      <div className="pick-up-from-your-container">
        <ul className="instant-booking">Pick-up from your house</ul>
      </div>
      <div className="drop-to-your-container">
        <ul className="instant-booking">Drop to your desired destination</ul>
      </div>
      <div className="completed-more-than-container">
        <ul className="instant-booking">
          Completed more than 20,000+ One-Way Trips
        </ul>
      </div>
      <div className="multiple-payment-option-container">
        <ul className="instant-booking">
          Multiple Payment Option including Credit Card.
        </ul>
      </div>
      <div className="rectangle-div" />
      <div className="discovering-indias-diverse">
        Discovering India's diverse landscapes, one scenic road trip at a time
      </div>
      <div className="experience-the-thrill-container">
        <ul className="experience-the-thrill-of-road">
          <li className="experience-the-thrill">
            Experience the thrill of road travel with our reliable car rental
            and taxi service as we explore the diverse landscapes of India
            together. We're passionate about making car hire accessible and
            enjoyable for everyone.
          </li>
        </ul>
        <p className="blank-line">&nbsp;</p>
        <ul className="experience-the-thrill-of-road">
          <li className="experience-the-thrill">
            Instead of worrying about the road, relax in our chauffeur-driven
            cabs on your next vacation. With a presence in over 2000 cities
            across India, we're here to take you wherever your heart desires
            with our car rental services.
          </li>
        </ul>
        <p className="blank-line">&nbsp;</p>
        <ul className="experience-the-thrill-of-road">
          <li className="experience-the-thrill">
            We cherish the freedom to stop, breathe in the fresh air, immerse in
            local cultures, and Savor regional cuisines along the way. These
            moments of discovery enrich your travels and create lasting memories
            through our rent a car service.
          </li>
        </ul>
        <p className="blank-line">&nbsp;</p>
        <ul className="experience-the-thrill-of-road">
          <li className="experience-the-thrill">
            No destination is too far or too close; we encourage you to explore
            the beauty around you with our car hire options. Pack your bags, set
            out on weekend adventures, and uncover the gems in your vicinity
            with our taxi service.
          </li>
        </ul>
        <p className="blank-line">&nbsp;</p>
        <ul className="experience-the-thrill-of-road">
          <li className="experience-the-thrill">
            Planning your trip is a breeze with our user-friendly website, or
            you can chat with our travel experts at 8960170877 for personalized
            guidance on car rental. Our cab booking app simplifies the process,
            ensuring a hassle-free experience when you rent a car.
          </li>
        </ul>
        <p className="blank-line">&nbsp;</p>
        <ul className="experience-the-thrill-of-road">
          <li className="experience-the-thrill">
            Our experienced drivers are your companions on the road, guiding you
            through India's best experiences with our car rental and taxi
            service. From booking to your safe return home, we're dedicated to
            ensuring you have an exceptional road trip.
          </li>
        </ul>
      </div>
      <div className="group-parent">
        <img className="group-child" alt="" src="/group-1000001863.svg" />
        <div className="why-pay-for">
          Why Pay for Return Journey when you are travelling one-way? Now get
          discounted AC Taxi at just half of the round trip cost for your
          one-way travel.
        </div>
      </div>
      <div className="return-fare-not">Return Fare, Not Fair!</div>
      <img
        className="vuesaxlineardriving-icon"
        alt=""
        src="/vuesaxlineardriving.svg"
      />
      <div className="lucknow-gorakhpur-varanasi-parent">
        <div className="lucknow-gorakhpur">
          Lucknow | Gorakhpur | Varanasi | Allahabad | Bareilly
        </div>
        <div className="now-available-routes">Now available routes are!</div>
      </div>
      <img
        className="uriel-soberanes-jg4e9uuxxqu-un-icon"
        alt=""
        src="/urielsoberanesjg4e9uuxxquunsplash-2@2x.png"
      />
      <div className="why-choose-ac">
        Why choose AC Bus or AC Train for your One-way Journey?
      </div>
      <div className="our-oneway-cab-container">
        <p className="blank-line">
          Our oneway cab service is cheaper than AC bus and 2 tier AC train
          ticket fares, it reduces your travel time and you travel at your own
          private space also to enjoy your journey. Our one way taxi will come
          at your doorstep and take you to your desired destination. So book you
          oneway cab from Lucknow to Gorakhpur or Varanasi to Bareilly.
        </p>
        <p className="blank-line">&nbsp;</p>
        <p className="read-more">read More....</p>
      </div>
      <div className="yatri-car-rental-container">
        <ul className="experience-the-thrill-of-road">
          <li className="experience-the-thrill">
            <span>
              Yatri Car Rental has been a trusted digital platform for booking
              local and outstation car rental and taxi services since 2014. Our
              primary goal is to offer our clients an exceptional car rental and
              cab booking experience, and we take great pride in our commitment
              to safety, reliability, and experienced drivers. These qualities
              are evident across all our car rental services, making us the
              preferred choice for those seeking rental cars and taxi services
              in INDIA. 
            </span>
          </li>
          <li className="experience-the-thrill">
            <b className="service-you-can">Service You Can Trust</b>
            <span className="service-you-can">
              {" "}
              - At Yatri Car Rental, we are dedicated to providing dependable
              services in INDIA. We guarantee that we won't cancel any bookings
              without advance notification, and our rental cars are meticulously
              maintained to ensure a seamless and stress-free journey for our
              clients. 
            </span>
          </li>
          <li className="experience-the-thrill">
            <b className="service-you-can">Safety is Our Priority</b>
            <span className="service-you-can">
              {" "}
              - Safety and comfort are paramount at Yatri Car Rental in INDIA.
              We exclusively hire experienced and skilled drivers who possess
              in-depth knowledge of the city's roads and traffic regulations.
              Our drivers are committed to delivering excellent customer service
              and ensuring a comfortable and stress-free travel experience for
              passengers. 
            </span>
          </li>
          <li className="experience-the-thrill">
            <b className="service-you-can">Expert Chauffeurs at Your Service</b>
            <span className="service-you-can">
              {" "}
              - Yatri Car Rental takes pride in selecting only the most skilled,
              knowledgeable, and courteous drivers to enhance the convenience
              and satisfaction of our clients. 
            </span>
          </li>
          <li className="experience-the-thrill">
            <b className="service-you-can">Extensive Industry Experience</b>
            <span className="service-you-can">
              {" "}
              - With over 10 years of industry expertise, Yatri Car Rental is
              your go-to choice for premium car hire services in Lucknow, Uttar
              Pradesh. 
            </span>
          </li>
          <li>
            <b className="service-you-can">Proven Track Record</b>
            <span className="service-you-can">
              {" "}
              - We place a strong emphasis on transparency in our billing system
              and consistently strive to provide a seamless and satisfactory
              experience for our customers. Our commitment to customer comfort
              and satisfaction is evident in our outstanding Google ratings,
              where we consistently receive ratings of 4.8 stars or higher.
            </span>
          </li>
        </ul>
      </div>
      <div className="why-choose-yatri1">Why Choose Yatri Car Rental?</div>
      <div className="landing-page-child1" />
      <div className="landing-page-child2" />
      <b className="outstation">Outstation</b>
      <div className="landing-page-child3" />
      <div className="landing-page-child4" />
      <div className="rectangle-parent">
        <div className="group-item" />
        <b className="one-way">One Way</b>
      </div>
      <div className="rectangle-group">
        <div className="group-inner" />
        <b className="explore-cabs">Explore Cabs</b>
      </div>
      <div className="rectangle-container">
        <div className="group-child1" />
        <b className="round-trip">Round Trip</b>
      </div>
      <b className="local">Local</b>
      <b className="airport">Airport</b>
      <div className="icon-parent">
        <img className="icon" alt="" src="/icon.svg" />
        <img className="icon1" alt="" src="/icon1.svg" />
        <b className="from">From</b>
        <b className="to">To</b>
        <b className="pick-up-date">Pick Up Date</b>
        <b className="pick-up-at">Pick Up At</b>
        <img className="group-child2" alt="" src="/vector-18.svg" />
        <img className="group-child3" alt="" src="/vector-19.svg" />
        <img className="group-child4" alt="" src="/vector-20.svg" />
        <img className="group-child5" alt="" src="/vector-21.svg" />
        <div className="start-typing-city">Start typing city</div>
        <div className="start-typing-city1">Start typing city</div>
        <div className="start-typing-date">Start typing Date</div>
        <div className="start-typing-time">Start typing Time</div>
        <img className="icon2" alt="" src="/icon2.svg" />
        <img className="icon3" alt="" src="/icon3.svg" />
      </div>
      <img
        className="untitled-design-1"
        alt=""
        src="/untitled-design-1@2x.png"
      />
      <div className="landing-page-child5" />
      <div className="landing-page-child6" />
      <img className="icon4" alt="" src="/icon4.svg" />
      <div className="account-setting">Account Setting</div>
      <div className="landing-page-child7" />
      <div className="log-out">Log Out</div>
      <img className="icon5" alt="" src="/icon5.svg" />
      <div className="landing-page-child8" />
      <div className="my-bookings">My Bookings</div>
      <img className="icon6" alt="" src="/icon6.svg" />
      <div className="privacy-policy">Privacy Policy</div>
      <div className="vector-parent">
        <img className="group-child6" alt="" src="/vector-8.svg" />
        <div className="group-child7" />
        <img className="group-child8" alt="" src="/vector-9.svg" />
        <div className="ellipse-div" />
        <img className="group-child9" alt="" src="/vector-10.svg" />
        <img className="group-child10" alt="" src="/vector-11.svg" />
        <div className="group-child11" />
        <div className="div">24</div>
        <div className="div1">7</div>
      </div>
      <div className="div2">+91876578984</div>
      <div className="group-div">
        <div className="group-child12" />
        <div className="rs11km">Rs.11/KM</div>
        <div className="rs11km1">Rs.11/KM</div>
        <div className="rs13km">Rs.13/KM</div>
        <div className="fare">Fare</div>
        <img className="group-icon" alt="" src="/group-1686551469.svg" />
        <div className="group-child13" />
        <div className="group-child14" />
        <div className="cab-type">Cab Type</div>
        <img className="vector-icon1" alt="" src="/vector1.svg" />
        <div className="ac-sedans">AC Sedans</div>
        <div className="ac-hatchbacks">AC Hatchbacks</div>
        <div className="ac-suv">{`AC SUV `}</div>
        <div className="pax">4 Pax</div>
        <div className="pax1">4 Pax</div>
        <div className="pax2">{`6-7 Pax `}</div>
        <div className="passengers">Passengers</div>
        <img className="vector-icon2" alt="" src="/vector2.svg" />
        <div className="comfortable-trips-with">
          Comfortable trips with small families
        </div>
        <div className="budget-trips-over">
          Budget trips over short distances
        </div>
        <div className="premium-trips-with">
          Premium trips with large families
        </div>
        <div className="ideal-for">Ideal For</div>
        <div className="etios-amaze-dzire">Etios, Amaze, Dzire etc.</div>
        <div className="wagon-r-celerio">Wagon R, Celerio, Micra etc.</div>
        <div className="ertiga-xylo-etc">{`Ertiga, Xylo etc. `}</div>
        <div className="models-include">Models Include</div>
        <img className="vector-icon3" alt="" src="/vector3.svg" />
        <div className="group-child15" />
        <div className="group-child16" />
        <div className="group-child17" />
      </div>
      <img className="landing-page-child9" alt="" src="/group-210.svg" />
      <img className="rectangle-icon" alt="" src="/rectangle-34624362.svg" />
      <div className="text-wrapper">
        <div className="text" />
      </div>
      <div className="newsletter">Newsletter</div>
      <div className="all-copyrights-are">
        All Copyrights are reserved by RIDE EVEE
      </div>
      <div className="ride-evee-logo-1-wrapper">
        <img
          className="ride-evee-logo-11"
          alt=""
          src="/ride-evee-logo-11@2x.png"
        />
      </div>
      <div className="home-parent">
        <div className="home">Home</div>
        <div className="about">About</div>
        <div className="services">Services</div>
        <div className="news">News</div>
        <div className="contact">Contact</div>
        <div className="privacy-policy-wrapper">
          <div className="home">Privacy Policy</div>
        </div>
      </div>
      <div className="rectangle-parent1">
        <div className="group-child18" />
        <div className="email">Email</div>
      </div>
      <div className="landing-page-child10" />
      <img className="vector-icon4" alt="" src="/vector4.svg" />
      <div className="download-app-parent">
        <div className="download-app">Download App</div>
        <div className="group-child19" />
        <img className="group-child20" alt="" src="/group-1686551413.svg" />
      </div>
      <img
        className="landing-page-child11"
        alt=""
        src="/group-1686551466.svg"
      />
      <img className="vector-icon5" alt="" src="/vector5.svg" />
      <div className="hi-ravi-parent">
        <div className="hi-ravi">Hi, Ravi</div>
        <img className="group-child21" alt="" src="/group-1686551467.svg" />
      </div>
    </div>
  );
};

export default LandingPage;
